# CampusCycle

CampusCycle is a campus second-hand marketplace for verified student users. Students can sign in with a `.edu` email, browse listings, post items, remove their own listings, search/filter products, and message sellers.

## Technology Stack

- Frontend: HTML5, CSS3, JavaScript
- Backend: Node.js HTTP server
- Database: PostgreSQL

## Backend Features

- `.edu` email login and automatic student registration
- Dynamic product data loaded from the backend
- CRUD foundation for listings:
  - Create listing
  - Read listings
  - Update own listing
  - Delete own listing
- Search, category filter, and sorting on frontend data loaded from backend
- Message storage between buyer and seller
- Product photo upload stored in the database as image data
- Booking/reservation system for buyers
- Automatic frontend refresh for near real-time product, booking, and message updates
- Persistent PostgreSQL tables for users, products, messages, and bookings

## Run Locally

Install dependencies:

```bash
npm install
```

Create a PostgreSQL database named `campuscycle`, then start the app:

```bash
npm start
```

Then open:

```text
http://localhost:3000
```

By default, the backend connects to:

```text
postgres://localhost:5432/campuscycle
```

To use a different database, set `DATABASE_URL` before starting:

```bash
DATABASE_URL=postgres://username:password@localhost:5432/campuscycle npm start
```

For deployment on Render, Railway, or a similar platform, set `DATABASE_URL` to your hosted PostgreSQL connection string.

## Deploy to Netlify

Netlify hosts the frontend as static files and runs the backend through Netlify Functions.

1. Push this project to GitHub.
2. Create a PostgreSQL database from Neon, Supabase, Railway, or another hosted PostgreSQL provider.
3. In Netlify, create a new site from the GitHub repository.
4. Use these build settings:
   - Build command: leave empty
   - Publish directory: `.`
   - Functions directory: `netlify/functions`
5. In Netlify environment variables, add:
   - `DATABASE_URL`: your hosted PostgreSQL connection string
6. Deploy the site.

The `netlify.toml` file redirects `/api/*` to the Netlify Function, so the frontend can keep using the same API paths.

## API Routes

- `POST /api/login` - login/register with a `.edu` email
- `GET /api/bootstrap` - load users, products, and messages
- `GET /api/products` - load product listings
- `POST /api/products` - create a new listing
- `PUT /api/products/:id` - update a seller's own listing
- `DELETE /api/products/:id` - delete a seller's own listing
- `POST /api/messages` - send and save a message
- `POST /api/bookings` - reserve a product

## Database Explanation

PostgreSQL stores four main tables:

- `users`: verified campus users
- `products`: marketplace listings
- `messages`: conversations grouped by product ID
- `bookings`: product reservations

The frontend communicates with the Node.js backend using `fetch()`, and the backend stores persistent data in PostgreSQL.

The database schema is documented in `schema.sql`. The server also creates the tables automatically on startup if they do not already exist.
