const crypto = require("crypto");
const { Pool } = require("pg");

const DATABASE_URL = process.env.DATABASE_URL || "postgres://localhost:5432/campuscycle";
const pool = new Pool({
  connectionString: DATABASE_URL,
  ssl: process.env.PGSSLMODE === "require" || /render|railway|neon|supabase|amazonaws/.test(DATABASE_URL)
    ? { rejectUnauthorized: false }
    : false
});

const seed = {
  users: [
    { id: "u1", name: "Alice Chen", email: "alice@sfsu.edu", avatar: "🧑‍🎓", rating: 4.8, joined: "2025-09" },
    { id: "u2", name: "Bob Wang", email: "bob@sfsu.edu", avatar: "👨‍💻", rating: 4.5, joined: "2025-10" },
    { id: "u3", name: "Carol Lin", email: "carol@sfsu.edu", avatar: "👩‍🔬", rating: 4.9, joined: "2025-08" },
    { id: "u4", name: "David Su", email: "david@sfsu.edu", avatar: "🧑‍🎨", rating: 4.2, joined: "2026-01" },
    { id: "u5", name: "Eva Park", email: "eva@sfsu.edu", avatar: "👩‍🏫", rating: 4.7, joined: "2025-11" }
  ],
  products: [
    { id: "p1", title: "Calculus: Early Transcendentals 8th Ed", price: 45, cat: "Textbooks", cond: "Good", desc: "Used for MATH 226. Some highlights.", img: "📗", sid: "u1", date: "2026-04-10", views: 32 },
    { id: "p2", title: "MacBook Air M2 13 inch", price: 680, cat: "Electronics", cond: "Like New", desc: "Bought 2025, barely used. Charger included.", img: "💻", sid: "u2", date: "2026-04-12", views: 128 },
    { id: "p3", title: "IKEA KALLAX Shelf Unit", price: 35, cat: "Furniture", cond: "Good", desc: "White 4-cube. Perfect for dorm.", img: "🗄️", sid: "u3", date: "2026-04-14", views: 47 },
    { id: "p4", title: "Organic Chemistry + Model Kit", price: 55, cat: "Textbooks", cond: "Fair", desc: "CHEM 215 bundle with annotations.", img: "📘", sid: "u5", date: "2026-04-08", views: 21 },
    { id: "p5", title: "Sony WH-1000XM5 Headphones", price: 180, cat: "Electronics", cond: "Good", desc: "Noise cancelling. Minor scratches.", img: "🎧", sid: "u4", date: "2026-04-15", views: 89 },
    { id: "p6", title: "Yoga Mat + Resistance Bands", price: 20, cat: "Sports", cond: "Like New", desc: "Used twice. 6mm anti-slip.", img: "🧘", sid: "u1", date: "2026-04-16", views: 15 },
    { id: "p7", title: "North Face Fleece Jacket M", price: 40, cat: "Clothing", cond: "Good", desc: "Mens medium black. Great for fog.", img: "🧥", sid: "u3", date: "2026-04-11", views: 53 },
    { id: "p8", title: "TI-84 Plus CE Calculator", price: 65, cat: "Electronics", cond: "Good", desc: "Works perfectly. USB cable.", img: "🔢", sid: "u2", date: "2026-04-13", views: 72 },
    { id: "p9", title: "Desk Lamp LED Adjustable", price: 15, cat: "Furniture", cond: "Like New", desc: "3 brightness USB port.", img: "💡", sid: "u5", date: "2026-04-17", views: 8 },
    { id: "p10", title: "Data Structures in Java", price: 30, cat: "Textbooks", cond: "Good", desc: "CSC 220 textbook clean.", img: "📕", sid: "u4", date: "2026-04-09", views: 44 },
    { id: "p11", title: "Basketball Spalding", price: 18, cat: "Sports", cond: "Fair", desc: "Intramurals. Holds air.", img: "🏀", sid: "u1", date: "2026-04-07", views: 19 },
    { id: "p12", title: "Mini Fridge Galanz 3.1", price: 75, cat: "Furniture", cond: "Good", desc: "Dorm fridge works great.", img: "🧊", sid: "u2", date: "2026-04-18", views: 61 }
  ],
  messages: [
    { pid: "p2", f: "u4", t: "u2", tx: "Hi! Still available?", tm: "2026-04-15 10:00" },
    { pid: "p2", f: "u2", t: "u4", tx: "Yes! Meet on campus?", tm: "2026-04-15 10:05" },
    { pid: "p2", f: "u4", t: "u2", tx: "Library lobby tomorrow 2pm?", tm: "2026-04-15 10:12" },
    { pid: "p5", f: "u1", t: "u4", tx: "Would you take $150?", tm: "2026-04-16 14:00" },
    { pid: "p5", f: "u4", t: "u1", tx: "How about $165?", tm: "2026-04-16 14:20" }
  ]
};

let initPromise;

function json(statusCode, data) {
  return {
    statusCode,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  };
}

function body(event) {
  return event.body ? JSON.parse(event.body) : {};
}

function apiPath(event) {
  const raw = event.path || "/";
  if (raw.startsWith("/api/")) return raw;
  return "/api/" + raw.replace(/^\/\.netlify\/functions\/api\/?/, "");
}

function publicUser(user) {
  return { id: user.id, name: user.name, email: user.email, avatar: user.avatar, rating: Number(user.rating), joined: user.joined };
}

function productRow(row) {
  return { id: row.id, title: row.title, price: Number(row.price), cat: row.cat, cond: row.cond, desc: row.description, img: row.img, sid: row.seller_id, date: row.posted_date, views: Number(row.views) };
}

function groupMessages(rows) {
  const grouped = {};
  for (const row of rows) {
    if (!grouped[row.product_id]) grouped[row.product_id] = [];
    grouped[row.product_id].push({ f: row.from_user, t: row.to_user, tx: row.text, tm: row.sent_at });
  }
  return grouped;
}

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      avatar TEXT NOT NULL,
      rating NUMERIC NOT NULL DEFAULT 5,
      joined TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      price NUMERIC NOT NULL,
      cat TEXT NOT NULL,
      cond TEXT NOT NULL,
      description TEXT NOT NULL,
      img TEXT NOT NULL,
      seller_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      posted_date TEXT NOT NULL,
      views INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY,
      product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
      from_user TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      to_user TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      text TEXT NOT NULL,
      sent_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS bookings (
      id TEXT PRIMARY KEY,
      product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
      buyer_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      seller_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      status TEXT NOT NULL DEFAULT 'Reserved',
      created_at TEXT NOT NULL,
      UNIQUE(product_id, buyer_id, status)
    );
  `);
  const count = await pool.query("SELECT COUNT(*)::int AS count FROM users");
  if (count.rows[0].count) return;

  for (const u of seed.users) {
    await pool.query("INSERT INTO users (id, name, email, avatar, rating, joined) VALUES ($1, $2, $3, $4, $5, $6)", [u.id, u.name, u.email, u.avatar, u.rating, u.joined]);
  }
  for (const p of seed.products) {
    await pool.query("INSERT INTO products (id, title, price, cat, cond, description, img, seller_id, posted_date, views) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)", [p.id, p.title, p.price, p.cat, p.cond, p.desc, p.img, p.sid, p.date, p.views]);
  }
  for (const [index, m] of seed.messages.entries()) {
    await pool.query("INSERT INTO messages (id, product_id, from_user, to_user, text, sent_at) VALUES ($1, $2, $3, $4, $5, $6)", ["m" + (index + 1), m.pid, m.f, m.t, m.tx, m.tm]);
  }
}

async function ready() {
  if (!initPromise) initPromise = initDb();
  return initPromise;
}

async function bootstrap() {
  const [users, products, messages, bookings] = await Promise.all([
    pool.query("SELECT * FROM users ORDER BY id"),
    pool.query("SELECT * FROM products ORDER BY posted_date DESC, id DESC"),
    pool.query("SELECT * FROM messages ORDER BY sent_at ASC, id ASC"),
    pool.query("SELECT * FROM bookings ORDER BY created_at DESC")
  ]);
  return {
    users: users.rows.map(publicUser),
    products: products.rows.map(productRow),
    messages: groupMessages(messages.rows),
    bookings: bookings.rows.map(row => ({ id: row.id, pid: row.product_id, uid: row.buyer_id, sellerId: row.seller_id, status: row.status, createdAt: row.created_at }))
  };
}

exports.handler = async function (event) {
  try {
    await ready();
    const method = event.httpMethod;
    const path = apiPath(event);

    if (method === "POST" && path === "/api/login") {
      const data = body(event);
      const email = String(data.email || "").trim().toLowerCase();
      if (!/^[^\s@]+@[^\s@]+\.edu$/.test(email)) return json(400, { error: "A valid .edu email is required." });
      let result = await pool.query("SELECT * FROM users WHERE LOWER(email) = $1", [email]);
      let user = result.rows[0];
      if (!user) {
        const name = email.split("@")[0].replace(/[._-]+/g, " ").replace(/\b\w/g, c => c.toUpperCase());
        user = { id: "u" + crypto.randomUUID().slice(0, 8), name, email, avatar: "🎓", rating: 5, joined: new Date().toISOString().slice(0, 7) };
        await pool.query("INSERT INTO users (id, name, email, avatar, rating, joined) VALUES ($1, $2, $3, $4, $5, $6)", [user.id, user.name, user.email, user.avatar, user.rating, user.joined]);
      }
      const users = await pool.query("SELECT * FROM users ORDER BY id");
      return json(200, { user: publicUser(user), users: users.rows.map(publicUser) });
    }

    if (method === "GET" && path === "/api/bootstrap") return json(200, await bootstrap());

    if (method === "GET" && path === "/api/products") {
      const products = await pool.query("SELECT * FROM products ORDER BY posted_date DESC, id DESC");
      return json(200, { products: products.rows.map(productRow) });
    }

    if (method === "POST" && path === "/api/products") {
      const data = body(event);
      const user = await pool.query("SELECT id FROM users WHERE id = $1", [data.sid]);
      if (!data.sid || !user.rows.length) return json(401, { error: "Login required." });
      if (!data.title || !data.desc || Number(data.price) <= 0) return json(400, { error: "Title, description and valid price are required." });
      const product = { id: "p" + Date.now(), title: String(data.title).trim(), price: Number(data.price), cat: String(data.cat || "Other"), cond: String(data.cond || "Good"), desc: String(data.desc).trim(), img: String(data.img || "📦"), sid: data.sid, date: new Date().toISOString().slice(0, 10), views: 0 };
      await pool.query("INSERT INTO products (id, title, price, cat, cond, description, img, seller_id, posted_date, views) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)", [product.id, product.title, product.price, product.cat, product.cond, product.desc, product.img, product.sid, product.date, product.views]);
      return json(201, { product });
    }

    const productMatch = path.match(/^\/api\/products\/([^/]+)$/);
    if (method === "PUT" && productMatch) {
      const data = body(event);
      const existing = await pool.query("SELECT * FROM products WHERE id = $1", [productMatch[1]]);
      const product = existing.rows[0];
      if (!product) return json(404, { error: "Product not found." });
      if (product.seller_id !== data.sid) return json(403, { error: "Only the seller can update this listing." });
      if (!data.title || !data.desc || Number(data.price) <= 0) return json(400, { error: "Title, description and valid price are required." });
      const updated = await pool.query("UPDATE products SET title = $1, price = $2, cat = $3, cond = $4, description = $5, img = $6 WHERE id = $7 RETURNING *", [String(data.title).trim(), Number(data.price), String(data.cat || "Other"), String(data.cond || "Good"), String(data.desc).trim(), String(data.img || "📦"), productMatch[1]]);
      return json(200, { product: productRow(updated.rows[0]) });
    }

    if (method === "DELETE" && productMatch) {
      const data = body(event);
      const existing = await pool.query("SELECT * FROM products WHERE id = $1", [productMatch[1]]);
      const product = existing.rows[0];
      if (!product) return json(404, { error: "Product not found." });
      if (product.seller_id !== data.sid) return json(403, { error: "Only the seller can delete this listing." });
      await pool.query("DELETE FROM products WHERE id = $1", [product.id]);
      return json(200, { ok: true });
    }

    if (method === "POST" && path === "/api/messages") {
      const data = body(event);
      if (!data.pid || !data.from || !data.to || !String(data.text || "").trim()) return json(400, { error: "Missing message data." });
      const message = { id: "m" + Date.now(), f: data.from, t: data.to, tx: String(data.text).trim(), tm: new Date().toISOString().replace("T", " ").slice(0, 16) };
      await pool.query("INSERT INTO messages (id, product_id, from_user, to_user, text, sent_at) VALUES ($1, $2, $3, $4, $5, $6)", [message.id, data.pid, message.f, message.t, message.tx, message.tm]);
      const messages = await pool.query("SELECT * FROM messages WHERE product_id = $1 ORDER BY sent_at ASC, id ASC", [data.pid]);
      return json(201, { message, messages: groupMessages(messages.rows)[data.pid] || [] });
    }

    if (method === "POST" && path === "/api/bookings") {
      const data = body(event);
      const productResult = await pool.query("SELECT * FROM products WHERE id = $1", [data.pid]);
      const product = productResult.rows[0];
      if (!product) return json(404, { error: "Product not found." });
      const user = await pool.query("SELECT id FROM users WHERE id = $1", [data.uid]);
      if (!data.uid || !user.rows.length) return json(401, { error: "Login required." });
      if (product.seller_id === data.uid) return json(400, { error: "You cannot reserve your own listing." });
      const existing = await pool.query("SELECT * FROM bookings WHERE product_id = $1 AND buyer_id = $2 AND status = 'Reserved'", [data.pid, data.uid]);
      if (!existing.rows.length) {
        await pool.query("INSERT INTO bookings (id, product_id, buyer_id, seller_id, status, created_at) VALUES ($1, $2, $3, $4, 'Reserved', $5)", ["b" + Date.now(), data.pid, data.uid, product.seller_id, new Date().toISOString().replace("T", " ").slice(0, 16)]);
      }
      const bookings = await pool.query("SELECT * FROM bookings ORDER BY created_at DESC");
      const mapped = bookings.rows.map(row => ({ id: row.id, pid: row.product_id, uid: row.buyer_id, sellerId: row.seller_id, status: row.status, createdAt: row.created_at }));
      return json(existing.rows.length ? 200 : 201, { booking: mapped.find(b => b.pid === data.pid && b.uid === data.uid), bookings: mapped });
    }

    return json(404, { error: "API route not found." });
  } catch (err) {
    return json(500, { error: err.message });
  }
};
