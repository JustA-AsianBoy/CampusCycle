const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { Pool } = require("pg");

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DATABASE_URL = process.env.DATABASE_URL || "postgres://localhost:5432/campuscycle";

const pool = new Pool({
  connectionString: DATABASE_URL,
  ssl: process.env.PGSSLMODE === "require" ? { rejectUnauthorized: false } : false
});

const seed = {
  users: [
    { id: "u1", name: "Alice Chen", email: "alice@sfsu.edu", avatar: "🧑‍🎓", rating: 4.8, joined: "2025-09" },
    { id: "u2", name: "Bob Wang", email: "bob@sfsu.edu", avatar: "👨‍💻", rating: 4.5, joined: "2025-10" },
    { id: "u3", name: "Carol Lin", email: "carol@sfsu.edu", avatar: "👩‍🔬", rating: 4.9, joined: "2025-08" },
    { id: "u4", name: "David Su", email: "david@sfsu.edu", avatar: "🧑‍🎨", rating: 4.2, joined: "2026-01" },
    { id: "u5", name: "Eva Park", email: "eva@sfsu.edu", avatar: "👩‍🏫", rating: 4.7, joined: "2025-11" }
  ],
  products: [
    { id: "p1", title: "Calculus: Early Transcendentals 8th Ed", price: 45, cat: "Textbooks", cond: "Good", desc: "Used for MATH 226. Some highlights.", img: "📗", sid: "u1", date: "2026-04-10", views: 32 },
    { id: "p2", title: "MacBook Air M2 13 inch", price: 680, cat: "Electronics", cond: "Like New", desc: "Bought 2025, barely used. Charger included.", img: "💻", sid: "u2", date: "2026-04-12", views: 128 },
    { id: "p3", title: "IKEA KALLAX Shelf Unit", price: 35, cat: "Furniture", cond: "Good", desc: "White 4-cube. Perfect for dorm.", img: "🗄️", sid: "u3", date: "2026-04-14", views: 47 },
    { id: "p4", title: "Organic Chemistry + Model Kit", price: 55, cat: "Textbooks", cond: "Fair", desc: "CHEM 215 bundle with annotations.", img: "📘", sid: "u5", date: "2026-04-08", views: 21 },
    { id: "p5", title: "Sony WH-1000XM5 Headphones", price: 180, cat: "Electronics", cond: "Good", desc: "Noise cancelling. Minor scratches.", img: "🎧", sid: "u4", date: "2026-04-15", views: 89 },
    { id: "p6", title: "Yoga Mat + Resistance Bands", price: 20, cat: "Sports", cond: "Like New", desc: "Used twice. 6mm anti-slip.", img: "🧘", sid: "u1", date: "2026-04-16", views: 15 },
    { id: "p7", title: "North Face Fleece Jacket M", price: 40, cat: "Clothing", cond: "Good", desc: "Mens medium black. Great for fog.", img: "🧥", sid: "u3", date: "2026-04-11", views: 53 },
    { id: "p8", title: "TI-84 Plus CE Calculator", price: 65, cat: "Electronics", cond: "Good", desc: "Works perfectly. USB cable.", img: "🔢", sid: "u2", date: "2026-04-13", views: 72 },
    { id: "p9", title: "Desk Lamp LED Adjustable", price: 15, cat: "Furniture", cond: "Like New", desc: "3 brightness USB port.", img: "💡", sid: "u5", date: "2026-04-17", views: 8 },
    { id: "p10", title: "Data Structures in Java", price: 30, cat: "Textbooks", cond: "Good", desc: "CSC 220 textbook clean.", img: "📕", sid: "u4", date: "2026-04-09", views: 44 },
    { id: "p11", title: "Basketball Spalding", price: 18, cat: "Sports", cond: "Fair", desc: "Intramurals. Holds air.", img: "🏀", sid: "u1", date: "2026-04-07", views: 19 },
    { id: "p12", title: "Mini Fridge Galanz 3.1", price: 75, cat: "Furniture", cond: "Good", desc: "Dorm fridge works great.", img: "🧊", sid: "u2", date: "2026-04-18", views: 61 }
  ],
  messages: [
    { pid: "p2", f: "u4", t: "u2", tx: "Hi! Still available?", tm: "2026-04-15 10:00" },
    { pid: "p2", f: "u2", t: "u4", tx: "Yes! Meet on campus?", tm: "2026-04-15 10:05" },
    { pid: "p2", f: "u4", t: "u2", tx: "Library lobby tomorrow 2pm?", tm: "2026-04-15 10:12" },
    { pid: "p5", f: "u1", t: "u4", tx: "Would you take $150?", tm: "2026-04-16 14:00" },
    { pid: "p5", f: "u4", t: "u1", tx: "How about $165?", tm: "2026-04-16 14:20" }
  ]
};

function send(res, status, data) {
  res.writeHead(status, { "Content-Type": "application/json" });
  res.end(JSON.stringify(data));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = "";
    req.on("data", chunk => raw += chunk);
    req.on("end", () => {
      try {
        resolve(raw ? JSON.parse(raw) : {});
      } catch (err) {
        reject(err);
      }
    });
  });
}

function publicUser(user) {
  return { id: user.id, name: user.name, email: user.email, avatar: user.avatar, rating: Number(user.rating), joined: user.joined };
}

function productRow(row) {
  return { id: row.id, title: row.title, price: Number(row.price), cat: row.cat, cond: row.cond, desc: row.description, img: row.img, sid: row.seller_id, date: row.posted_date, views: Number(row.views) };
}

function groupMessages(rows) {
  const grouped = {};
  for (const row of rows) {
    if (!grouped[row.product_id]) grouped[row.product_id] = [];
    grouped[row.product_id].push({ f: row.from_user, t: row.to_user, tx: row.text, tm: row.sent_at });
  }
  return grouped;
}

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      avatar TEXT NOT NULL,
      rating NUMERIC NOT NULL DEFAULT 5,
      joined TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      price NUMERIC NOT NULL,
      cat TEXT NOT NULL,
      cond TEXT NOT NULL,
      description TEXT NOT NULL,
      img TEXT NOT NULL,
      seller_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      posted_date TEXT NOT NULL,
      views INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY,
      product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
      from_user TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      to_user TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      text TEXT NOT NULL,
      sent_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS bookings (
      id TEXT PRIMARY KEY,
      product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
      buyer_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      seller_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      status TEXT NOT NULL DEFAULT 'Reserved',
      created_at TEXT NOT NULL,
      UNIQUE(product_id, buyer_id, status)
    );
  `);

  const userCount = await pool.query("SELECT COUNT(*)::int AS count FROM users");
  if (userCount.rows[0].count > 0) return;

  for (const u of seed.users) {
    await pool.query(
      "INSERT INTO users (id, name, email, avatar, rating, joined) VALUES ($1, $2, $3, $4, $5, $6)",
      [u.id, u.name, u.email, u.avatar, u.rating, u.joined]
    );
  }
  for (const p of seed.products) {
    await pool.query(
      "INSERT INTO products (id, title, price, cat, cond, description, img, seller_id, posted_date, views) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)",
      [p.id, p.title, p.price, p.cat, p.cond, p.desc, p.img, p.sid, p.date, p.views]
    );
  }
  for (const [index, m] of seed.messages.entries()) {
    await pool.query(
      "INSERT INTO messages (id, product_id, from_user, to_user, text, sent_at) VALUES ($1, $2, $3, $4, $5, $6)",
      ["m" + (index + 1), m.pid, m.f, m.t, m.tx, m.tm]
    );
  }
}

async function getBootstrap() {
  const [users, products, messages, bookings] = await Promise.all([
    pool.query("SELECT * FROM users ORDER BY id"),
    pool.query("SELECT * FROM products ORDER BY posted_date DESC, id DESC"),
    pool.query("SELECT * FROM messages ORDER BY sent_at ASC, id ASC"),
    pool.query("SELECT * FROM bookings ORDER BY created_at DESC")
  ]);

  return {
    users: users.rows.map(publicUser),
    products: products.rows.map(productRow),
    messages: groupMessages(messages.rows),
    bookings: bookings.rows.map(row => ({ id: row.id, pid: row.product_id, uid: row.buyer_id, sellerId: row.seller_id, status: row.status, createdAt: row.created_at }))
  };
}

async function handleApi(req, res, url) {
  if (req.method === "POST" && url.pathname === "/api/login") {
    const body = await readBody(req);
    const email = String(body.email || "").trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.edu$/.test(email)) return send(res, 400, { error: "A valid .edu email is required." });

    let result = await pool.query("SELECT * FROM users WHERE LOWER(email) = $1", [email]);
    let user = result.rows[0];
    if (!user) {
      const name = email.split("@")[0].replace(/[._-]+/g, " ").replace(/\b\w/g, c => c.toUpperCase());
      user = { id: "u" + crypto.randomUUID().slice(0, 8), name, email, avatar: "🎓", rating: 5, joined: new Date().toISOString().slice(0, 7) };
      await pool.query("INSERT INTO users (id, name, email, avatar, rating, joined) VALUES ($1, $2, $3, $4, $5, $6)", [user.id, user.name, user.email, user.avatar, user.rating, user.joined]);
    }
    const users = await pool.query("SELECT * FROM users ORDER BY id");
    return send(res, 200, { user: publicUser(user), users: users.rows.map(publicUser) });
  }

  if (req.method === "GET" && url.pathname === "/api/bootstrap") {
    return send(res, 200, await getBootstrap());
  }

  if (req.method === "GET" && url.pathname === "/api/products") {
    const products = await pool.query("SELECT * FROM products ORDER BY posted_date DESC, id DESC");
    return send(res, 200, { products: products.rows.map(productRow) });
  }

  if (req.method === "POST" && url.pathname === "/api/products") {
    const body = await readBody(req);
    const user = await pool.query("SELECT id FROM users WHERE id = $1", [body.sid]);
    if (!body.sid || !user.rows.length) return send(res, 401, { error: "Login required." });
    if (!body.title || !body.desc || Number(body.price) <= 0) return send(res, 400, { error: "Title, description and valid price are required." });

    const product = {
      id: "p" + Date.now(),
      title: String(body.title).trim(),
      price: Number(body.price),
      cat: String(body.cat || "Other"),
      cond: String(body.cond || "Good"),
      desc: String(body.desc).trim(),
      img: String(body.img || "📦"),
      sid: body.sid,
      date: new Date().toISOString().slice(0, 10),
      views: 0
    };
    await pool.query(
      "INSERT INTO products (id, title, price, cat, cond, description, img, seller_id, posted_date, views) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)",
      [product.id, product.title, product.price, product.cat, product.cond, product.desc, product.img, product.sid, product.date, product.views]
    );
    return send(res, 201, { product });
  }

  const productMatch = url.pathname.match(/^\/api\/products\/([^/]+)$/);

  if (req.method === "PUT" && productMatch) {
    const body = await readBody(req);
    const existing = await pool.query("SELECT * FROM products WHERE id = $1", [productMatch[1]]);
    const product = existing.rows[0];
    if (!product) return send(res, 404, { error: "Product not found." });
    if (product.seller_id !== body.sid) return send(res, 403, { error: "Only the seller can update this listing." });
    if (!body.title || !body.desc || Number(body.price) <= 0) return send(res, 400, { error: "Title, description and valid price are required." });

    const updated = await pool.query(
      "UPDATE products SET title = $1, price = $2, cat = $3, cond = $4, description = $5, img = $6 WHERE id = $7 RETURNING *",
      [String(body.title).trim(), Number(body.price), String(body.cat || "Other"), String(body.cond || "Good"), String(body.desc).trim(), String(body.img || "📦"), productMatch[1]]
    );
    return send(res, 200, { product: productRow(updated.rows[0]) });
  }

  if (req.method === "DELETE" && productMatch) {
    const body = await readBody(req);
    const existing = await pool.query("SELECT * FROM products WHERE id = $1", [productMatch[1]]);
    const product = existing.rows[0];
    if (!product) return send(res, 404, { error: "Product not found." });
    if (product.seller_id !== body.sid) return send(res, 403, { error: "Only the seller can delete this listing." });
    await pool.query("DELETE FROM products WHERE id = $1", [product.id]);
    return send(res, 200, { ok: true });
  }

  if (req.method === "POST" && url.pathname === "/api/messages") {
    const body = await readBody(req);
    if (!body.pid || !body.from || !body.to || !String(body.text || "").trim()) return send(res, 400, { error: "Missing message data." });
    const message = { id: "m" + Date.now(), f: body.from, t: body.to, tx: String(body.text).trim(), tm: new Date().toISOString().replace("T", " ").slice(0, 16) };
    await pool.query(
      "INSERT INTO messages (id, product_id, from_user, to_user, text, sent_at) VALUES ($1, $2, $3, $4, $5, $6)",
      [message.id, body.pid, message.f, message.t, message.tx, message.tm]
    );
    const messages = await pool.query("SELECT * FROM messages WHERE product_id = $1 ORDER BY sent_at ASC, id ASC", [body.pid]);
    return send(res, 201, { message, messages: groupMessages(messages.rows)[body.pid] || [] });
  }

  if (req.method === "POST" && url.pathname === "/api/bookings") {
    const body = await readBody(req);
    const productResult = await pool.query("SELECT * FROM products WHERE id = $1", [body.pid]);
    const product = productResult.rows[0];
    if (!product) return send(res, 404, { error: "Product not found." });
    const user = await pool.query("SELECT id FROM users WHERE id = $1", [body.uid]);
    if (!body.uid || !user.rows.length) return send(res, 401, { error: "Login required." });
    if (product.seller_id === body.uid) return send(res, 400, { error: "You cannot reserve your own listing." });

    const existing = await pool.query("SELECT * FROM bookings WHERE product_id = $1 AND buyer_id = $2 AND status = 'Reserved'", [body.pid, body.uid]);
    if (!existing.rows.length) {
      await pool.query(
        "INSERT INTO bookings (id, product_id, buyer_id, seller_id, status, created_at) VALUES ($1, $2, $3, $4, 'Reserved', $5)",
        ["b" + Date.now(), body.pid, body.uid, product.seller_id, new Date().toISOString().replace("T", " ").slice(0, 16)]
      );
    }
    const bookings = await pool.query("SELECT * FROM bookings ORDER BY created_at DESC");
    const mapped = bookings.rows.map(row => ({ id: row.id, pid: row.product_id, uid: row.buyer_id, sellerId: row.seller_id, status: row.status, createdAt: row.created_at }));
    return send(res, existing.rows.length ? 200 : 201, { booking: mapped.find(b => b.pid === body.pid && b.uid === body.uid), bookings: mapped });
  }

  return send(res, 404, { error: "API route not found." });
}

function serveStatic(req, res, url) {
  const pathname = url.pathname === "/" ? "/index.html" : decodeURIComponent(url.pathname);
  const file = path.normalize(path.join(ROOT, pathname));
  if (!file.startsWith(ROOT)) {
    res.writeHead(403);
    return res.end("Forbidden");
  }
  const ext = path.extname(file).toLowerCase();
  const types = { ".html": "text/html", ".css": "text/css", ".js": "application/javascript", ".json": "application/json", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg" };
  fs.readFile(file, (err, data) => {
    if (err) {
      res.writeHead(404);
      return res.end("Not found");
    }
    res.writeHead(200, { "Content-Type": types[ext] || "application/octet-stream" });
    res.end(data);
  });
}

async function start() {
  await initDb();
  http.createServer((req, res) => {
    const url = new URL(req.url, `http://${req.headers.host}`);
    if (url.pathname.startsWith("/api/")) {
      handleApi(req, res, url).catch(err => send(res, 500, { error: err.message }));
    } else {
      serveStatic(req, res, url);
    }
  }).listen(PORT, () => {
    console.log(`CampusCycle running at http://localhost:${PORT}`);
    console.log(`PostgreSQL database: ${DATABASE_URL.replace(/:[^:@/]+@/, ":****@")}`);
  });
}

start().catch(err => {
  console.error("Failed to start CampusCycle.");
  console.error("Make sure PostgreSQL is running and DATABASE_URL is set.");
  console.error("Example: DATABASE_URL=postgres://localhost:5432/campuscycle npm start");
  console.error(err.message);
  process.exit(1);
});
