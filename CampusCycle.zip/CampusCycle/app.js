var API="";
var backendReady=false;

async function api(path, options){
  var res=await fetch(API+path,Object.assign({
    headers:{"Content-Type":"application/json"}
  },options||{}));
  var data=await res.json();
  if(!res.ok)throw new Error(data.error||"Server error");
  return data;
}

async function loadData(){
  try{
    var data=await api("/api/bootstrap");
    USERS=data.users||USERS;
    products=data.products||products;
    msgs=data.messages||msgs;
    bookings=data.bookings||bookings;
    backendReady=true;
  }catch(e){
    backendReady=false;
    toast("Backend offline: using demo data only.");
  }
}

var USERS=[
  {id:"u1",name:"Alice Chen",email:"alice@sfsu.edu",avatar:"🧑‍🎓",rating:4.8,joined:"2025-09"},
  {id:"u2",name:"Bob Wang",email:"bob@sfsu.edu",avatar:"👨‍💻",rating:4.5,joined:"2025-10"},
  {id:"u3",name:"Carol Lin",email:"carol@sfsu.edu",avatar:"👩‍🔬",rating:4.9,joined:"2025-08"},
  {id:"u4",name:"David Su",email:"david@sfsu.edu",avatar:"🧑‍🎨",rating:4.2,joined:"2026-01"},
  {id:"u5",name:"Eva Park",email:"eva@sfsu.edu",avatar:"👩‍🏫",rating:4.7,joined:"2025-11"}
  ];
  var CATS=["All","Textbooks","Electronics","Furniture","Clothing","Sports","Other"];
  var CONDS=["Like New","Good","Fair","Used"];
  var ICONS=["📗","💻","🗄️","📘","🎧","🧘","🧥","🔢","💡","📕","🏀","🧊","📦","🎒"];
  var products=[
  {id:"p1",title:"Calculus: Early Transcendentals 8th Ed",price:45,cat:"Textbooks",cond:"Good",desc:"Used for MATH 226. Some highlights.",img:"📗",sid:"u1",date:"2026-04-10",views:32},
  {id:"p2",title:"MacBook Air M2 13 inch",price:680,cat:"Electronics",cond:"Like New",desc:"Bought 2025, barely used. Charger included.",img:"💻",sid:"u2",date:"2026-04-12",views:128},
  {id:"p3",title:"IKEA KALLAX Shelf Unit",price:35,cat:"Furniture",cond:"Good",desc:"White 4-cube. Perfect for dorm.",img:"🗄️",sid:"u3",date:"2026-04-14",views:47},
  {id:"p4",title:"Organic Chemistry + Model Kit",price:55,cat:"Textbooks",cond:"Fair",desc:"CHEM 215 bundle with annotations.",img:"📘",sid:"u5",date:"2026-04-08",views:21},
  {id:"p5",title:"Sony WH-1000XM5 Headphones",price:180,cat:"Electronics",cond:"Good",desc:"Noise cancelling. Minor scratches.",img:"🎧",sid:"u4",date:"2026-04-15",views:89},
  {id:"p6",title:"Yoga Mat + Resistance Bands",price:20,cat:"Sports",cond:"Like New",desc:"Used twice. 6mm anti-slip.",img:"🧘",sid:"u1",date:"2026-04-16",views:15},
  {id:"p7",title:"North Face Fleece Jacket M",price:40,cat:"Clothing",cond:"Good",desc:"Mens medium black. Great for fog.",img:"🧥",sid:"u3",date:"2026-04-11",views:53},
  {id:"p8",title:"TI-84 Plus CE Calculator",price:65,cat:"Electronics",cond:"Good",desc:"Works perfectly. USB cable.",img:"🔢",sid:"u2",date:"2026-04-13",views:72},
  {id:"p9",title:"Desk Lamp LED Adjustable",price:15,cat:"Furniture",cond:"Like New",desc:"3 brightness USB port.",img:"💡",sid:"u5",date:"2026-04-17",views:8},
  {id:"p10",title:"Data Structures in Java",price:30,cat:"Textbooks",cond:"Good",desc:"CSC 220 textbook clean.",img:"📕",sid:"u4",date:"2026-04-09",views:44},
  {id:"p11",title:"Basketball Spalding",price:18,cat:"Sports",cond:"Fair",desc:"Intramurals. Holds air.",img:"🏀",sid:"u1",date:"2026-04-07",views:19},
  {id:"p12",title:"Mini Fridge Galanz 3.1",price:75,cat:"Furniture",cond:"Good",desc:"Dorm fridge works great.",img:"🧊",sid:"u2",date:"2026-04-18",views:61}
  ];
  var msgs={"p2":[{f:"u4",t:"u2",tx:"Hi! Still available?",tm:"2026-04-15 10:00"},{f:"u2",t:"u4",tx:"Yes! Meet on campus?",tm:"2026-04-15 10:05"},{f:"u4",t:"u2",tx:"Library lobby tomorrow 2pm?",tm:"2026-04-15 10:12"}],"p5":[{f:"u1",t:"u4",tx:"Would you take $150?",tm:"2026-04-16 14:00"},{f:"u4",t:"u1",tx:"How about $165?",tm:"2026-04-16 14:20"}]};
  var bookings=[];
  
  var me=null,selP=null,editP=null,chatT=null,selCat="All",sortVal="newest",curPage="login",refreshTimer=null;
  var postF={i:"📦",c:"Textbooks",co:"Good"};
  
  function getUser(id){for(var i=0;i<USERS.length;i++)if(USERS[i].id===id)return USERS[i];return me;}
  function esc(s){var d=document.createElement("div");d.textContent=s;return d.innerHTML;}
  function isNew(d){return(new Date()-new Date(d))/864e5<=7;}
  function toast(m){var t=document.getElementById("toastEl");t.textContent=m;t.style.display="block";setTimeout(function(){t.style.display="none";},2500);}
  function isPhoto(img){return typeof img==="string"&&img.indexOf("data:image/")===0;}
  function thumb(img,cls){return isPhoto(img)?'<img class="'+cls+'" src="'+img+'" alt="">':img;}
  function hasBooking(pid){for(var i=0;i<bookings.length;i++)if(bookings[i].pid===pid&&bookings[i].status==="Reserved")return bookings[i];return null;}
  
  async function doLogin(){
    var email=document.getElementById("emailInput").value.trim();
    var at=email.indexOf("@");
    var domain=at>0?email.substring(at+1):"";
    var err=document.getElementById("loginErr");
    if(domain.length<5||domain.substring(domain.length-4)!==".edu"){
      err.textContent="Please use a valid .edu email.";err.style.display="block";return;}
    err.style.display="none";
    try{
      var data=await api("/api/login",{method:"POST",body:JSON.stringify({email:email})});
      me=data.user;
      USERS=data.users||USERS;
      await loadData();
    }catch(e){
      me=null;
      for(var i=0;i<USERS.length;i++)if(USERS[i].email===email){me=USERS[i];break;}
      if(!me)me={id:"u_new",name:email.substring(0,at),email:email,avatar:"🎓",rating:5.0,joined:"2026-04"};
      backendReady=false;
      toast("Could not reach backend. Demo mode started.");
    }
    showPage("home");
    startLiveUpdates();
  }
  
  function startLiveUpdates(){
    if(refreshTimer)clearInterval(refreshTimer);
    refreshTimer=setInterval(async function(){
      if(!me||curPage==="post")return;
      await loadData();
      if(selP){for(var i=0;i<products.length;i++)if(products[i].id===selP.id){selP=products[i];break;}}
      if(curPage==="home")renderHome();
      if(curPage==="detail")renderDetail();
      if(curPage==="chat")renderChat();
      if(curPage==="cr")renderCR();
      if(curPage==="profile")renderProfile();
    },5000);
  }

  function doLogout(){me=null;if(refreshTimer)clearInterval(refreshTimer);document.getElementById("appShell").style.display="none";document.getElementById("loginPage").style.display="flex";}
  
  function newPost(){editP=null;showPage("post");}

  function showPage(name){
    curPage=name;
    document.getElementById("loginPage").style.display="none";
    document.getElementById("appShell").style.display="block";
    var pages=document.getElementsByClassName("appPage");
    for(var i=0;i<pages.length;i++)pages[i].style.display="none";
    var navIds=["home","post","chat","profile"];
    for(var i=0;i<navIds.length;i++){var el=document.getElementById("nav-"+navIds[i]);if(el){el.className=navIds[i]===name?"nvb act":"nvb";}}
    if(name==="home"){document.getElementById("homePage").style.display="block";renderHome();}
    if(name==="detail"){document.getElementById("detailPage").style.display="block";renderDetail();}
    if(name==="post"){document.getElementById("postPage").style.display="block";renderPost();}
    if(name==="chat"){document.getElementById("chatPage").style.display="block";renderChat();}
    if(name==="cr"){document.getElementById("crPage").style.display="flex";renderCR();}
    if(name==="profile"){document.getElementById("profilePage").style.display="block";renderProfile();}
  }
  
  function getFiltered(){
    var q=document.getElementById("searchInput")?document.getElementById("searchInput").value.toLowerCase():"";
    var r=[];
    for(var i=0;i<products.length;i++){var p=products[i];
      if(selCat!=="All"&&p.cat!==selCat)continue;
      if(q&&p.title.toLowerCase().indexOf(q)===-1&&p.desc.toLowerCase().indexOf(q)===-1)continue;
      r.push(p);}
    r.sort(function(a,b){
      if(sortVal==="newest")return b.date>a.date?1:b.date<a.date?-1:0;
      if(sortVal==="price_low")return a.price-b.price;
      if(sortVal==="price_high")return b.price-a.price;
      if(sortVal==="popular")return b.views-a.views;return 0;});
    return r;
  }
  
  function renderHome(){
    var tc=document.getElementById("catTabs");tc.innerHTML="";
    for(var i=0;i<CATS.length;i++){(function(c){
      var b=document.createElement("button");b.className="ctb"+(selCat===c?" act":"");b.textContent=c;
      b.onclick=function(){selCat=c;renderHome();};tc.appendChild(b);
    })(CATS[i]);}
    var f=getFiltered(),g=document.getElementById("productGrid"),em=document.getElementById("emptyState");
    document.getElementById("resultCount").textContent=f.length+" item"+(f.length!==1?"s":"")+" found";
    if(!f.length){g.innerHTML="";em.style.display="block";}
    else{em.style.display="none";g.innerHTML="";
      for(var i=0;i<f.length;i++){(function(p){
        var s=getUser(p.sid);var card=document.createElement("div");card.className="pc";
        var bk=hasBooking(p.id);
        card.innerHTML='<div class="cimg">'+thumb(p.img,"pimg")+(isNew(p.date)?'<span class="bnw">NEW</span>':'')+'<span class="bco">'+(bk?"Reserved":esc(p.cond))+'</span></div><div class="ci2"><div class="cti">'+esc(p.title)+'</div><div class="cr2"><span class="cp">$'+p.price+'</span><span class="cs2">'+s.avatar+' '+esc(s.name.split(" ")[0])+'</span></div><div class="cf2"><span class="ccat">'+esc(p.cat)+'</span><span class="cv2">👁 '+p.views+'</span></div></div>';
        card.onclick=function(){selP=p;showPage("detail");};g.appendChild(card);
      })(f[i]);}
    }
  }
  
  function renderDetail(){
    var p=selP;if(!p)return;var s=getUser(p.sid),own=me&&me.id===p.sid;
    document.getElementById("detailImg").innerHTML=isPhoto(p.img)?'<img class="bigpimg" src="'+p.img+'" alt="">':'<span style="font-size:96px">'+p.img+'</span>';
    document.getElementById("detailTitle").textContent=p.title;
    document.getElementById("detailPrice").textContent="$"+p.price;
    document.getElementById("detailBadges").innerHTML='<span class="dbdg dbcat">'+esc(p.cat)+'</span><span class="dbdg dbcon">'+esc(p.cond)+'</span>';
    document.getElementById("detailDesc").textContent=p.desc;
    document.getElementById("detailMeta").innerHTML='<span>📅 '+p.date+'</span><span> · </span><span>👁 '+p.views+' views</span>';
    document.getElementById("detailSeller").innerHTML='<span style="font-size:36px">'+s.avatar+'</span><div style="flex:1"><div style="font-weight:600;font-size:15px">'+esc(s.name)+'</div><div style="font-size:13px;color:var(--mut)">⭐ '+s.rating+' · Joined '+s.joined+'</div></div><span style="background:var(--pri);color:#fff;font-size:11px;font-weight:700;padding:4px 10px;border-radius:8px">✓ Verified</span>';
    var act=document.getElementById("detailActions");
    var bk=hasBooking(p.id),reservedByMe=bk&&bk.uid===me.id;
    if(own)act.innerHTML='<button class="btn bs" onclick="editP=selP;showPage(\'post\')">Edit Listing</button><button class="btn bd" onclick="deleteItem(\''+p.id+'\')">Remove Listing</button>';
    else act.innerHTML='<button class="btn bs" onclick="reserveItem(\''+p.id+'\')" '+(bk?'disabled style="opacity:.6"':'')+'>'+(reservedByMe?'Reserved by You':bk?'Reserved':'Reserve Item')+'</button><button class="btn bp" onclick="chatT={pid:\''+p.id+'\',uid:\''+p.sid+'\'};showPage(\'cr\')">Contact Seller</button>';
  }

  async function reserveItem(id){
    try{
      var data=await api("/api/bookings",{method:"POST",body:JSON.stringify({pid:id,uid:me.id})});
      bookings=data.bookings||bookings;
    }catch(e){
      bookings.push({id:"b"+Date.now(),pid:id,uid:me.id,sellerId:selP.sid,status:"Reserved",createdAt:new Date().toISOString().replace("T"," ").slice(0,16)});
    }
    renderDetail();toast("Item reserved!");
  }
  
  async function deleteItem(id){
    try{
      await api("/api/products/"+encodeURIComponent(id),{method:"DELETE",body:JSON.stringify({sid:me.id})});
      await loadData();
    }catch(e){
      products=products.filter(function(x){return x.id!==id;});
    }
    showPage("home");toast("Item removed.");
  }
  
  function renderPost(){
    var editing=!!editP;
    postF={i:editing?editP.img:"📦",c:editing?editP.cat:"Textbooks",co:editing?editP.cond:"Good"};
    document.getElementById("postHeading").textContent=editing?"Edit Listing":"Post an Item for Sale";
    document.getElementById("postSubmitBtn").textContent=editing?"Save Changes":"Post Item";
    var ip=document.getElementById("iconPicker");ip.innerHTML="";
    for(var i=0;i<ICONS.length;i++){(function(ic){
      var b=document.createElement("button");b.className="ib"+(postF.i===ic?" act":"");b.textContent=ic;
      b.onclick=function(){postF.i=ic;for(var j=0;j<ip.children.length;j++)ip.children[j].classList.remove("act");b.classList.add("act");};
      ip.appendChild(b);
    })(ICONS[i]);}
    var cs=document.getElementById("postCat");cs.innerHTML="";
    for(var i=1;i<CATS.length;i++){var o=document.createElement("option");o.textContent=CATS[i];cs.appendChild(o);}
    cs.value=postF.c;cs.onchange=function(){postF.c=cs.value;};
    var cp=document.getElementById("condPicker");cp.innerHTML="";
    for(var i=0;i<CONDS.length;i++){(function(c){
      var b=document.createElement("button");b.className="cob"+(postF.co===c?" act":"");b.textContent=c;
      b.onclick=function(){postF.co=c;for(var j=0;j<cp.children.length;j++)cp.children[j].classList.remove("act");b.classList.add("act");};
      cp.appendChild(b);
    })(CONDS[i]);}
    document.getElementById("postTitle").value=editing?editP.title:"";
    document.getElementById("postPrice").value=editing?editP.price:"";
    document.getElementById("postDesc").value=editing?editP.desc:"";
    document.getElementById("errTitle").style.display="none";document.getElementById("errPrice").style.display="none";document.getElementById("errDesc").style.display="none";
    renderImagePreview();
  }

  function renderImagePreview(){
    var prev=document.getElementById("imagePreview");
    if(!prev)return;
    if(isPhoto(postF.i)){prev.innerHTML='<img src="'+postF.i+'" alt="">';prev.style.display="block";}
    else{prev.innerHTML="";prev.style.display="none";}
  }

  function handleImageUpload(e){
    var file=e.target.files&&e.target.files[0];if(!file)return;
    if(file.size>900000){toast("Please choose an image under 900KB.");e.target.value="";return;}
    var reader=new FileReader();
    reader.onload=function(){postF.i=reader.result;var ip=document.getElementById("iconPicker");for(var j=0;j<ip.children.length;j++)ip.children[j].classList.remove("act");renderImagePreview();toast("Photo attached.");};
    reader.readAsDataURL(file);
  }
  
  async function submitPost(){
    var ti=document.getElementById("postTitle").value.trim(),pr=document.getElementById("postPrice").value.trim(),ds=document.getElementById("postDesc").value.trim(),ok=true;
    if(!ti){document.getElementById("errTitle").textContent="Title required";document.getElementById("errTitle").style.display="block";ok=false;}else document.getElementById("errTitle").style.display="none";
    if(!pr||isNaN(pr)||Number(pr)<=0){document.getElementById("errPrice").textContent="Valid price required";document.getElementById("errPrice").style.display="block";ok=false;}else document.getElementById("errPrice").style.display="none";
    if(!ds){document.getElementById("errDesc").textContent="Description required";document.getElementById("errDesc").style.display="block";ok=false;}else document.getElementById("errDesc").style.display="none";
    if(!ok)return;
    var item={title:ti,price:Number(pr),cat:postF.c,cond:postF.co,desc:ds,img:postF.i,sid:me.id};
    if(editP){
      try{
        var updated=await api("/api/products/"+encodeURIComponent(editP.id),{method:"PUT",body:JSON.stringify(item)});
        for(var i=0;i<products.length;i++)if(products[i].id===editP.id)products[i]=updated.product;
        selP=updated.product;
        await loadData();
        for(var j=0;j<products.length;j++)if(products[j].id===selP.id){selP=products[j];break;}
      }catch(e){
        for(var k=0;k<products.length;k++)if(products[k].id===editP.id)products[k]=Object.assign({},products[k],item);
        selP=Object.assign({},editP,item);
      }
      editP=null;
      showPage("detail");toast("Listing updated!");
      return;
    }
    try{
      var data=await api("/api/products",{method:"POST",body:JSON.stringify(item)});
      products.unshift(data.product);
      await loadData();
    }catch(e){
      products.unshift(Object.assign({id:"p"+Date.now(),date:new Date().toISOString().slice(0,10),views:0},item));
    }
    showPage("home");toast("Item posted!");
  }
  
  function renderChat(){
    var th=[];var ks=Object.keys(msgs);
    for(var i=0;i<ks.length;i++){var pid=ks[i],ms=msgs[pid],rel=[];
      for(var j=0;j<ms.length;j++)if(ms[j].f===me.id||ms[j].t===me.id)rel.push(ms[j]);
      if(!rel.length)continue;var last=rel[rel.length-1],oid=last.f===me.id?last.t:last.f;
      var prod=null;for(var j=0;j<products.length;j++)if(products[j].id===pid){prod=products[j];break;}
      th.push({pid:pid,uid:oid,last:last,prod:prod});}
    var cl=document.getElementById("chatList"),ce=document.getElementById("chatEmpty");
    if(!th.length){cl.innerHTML="";ce.style.display="block";}
    else{ce.style.display="none";cl.innerHTML="";
      for(var i=0;i<th.length;i++){(function(t){
        var o=getUser(t.uid);var d=document.createElement("div");d.className="cth";
        d.innerHTML='<span style="font-size:32px">'+o.avatar+'</span><div style="flex:1;min-width:0"><div style="font-weight:600;font-size:14px">'+esc(o.name)+'</div><div style="font-size:13px;color:var(--mut);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+esc(t.last.tx)+'</div></div><div style="text-align:right"><div style="font-size:11px;color:var(--mut)">'+t.last.tm.slice(11)+'</div>'+(t.prod?'<span style="font-size:11px;background:var(--pril);color:var(--pri);padding:2px 8px;border-radius:6px;font-weight:600;display:inline-block;margin-top:4px">'+t.prod.img+' $'+t.prod.price+'</span>':'')+'</div>';
        d.onclick=function(){chatT={pid:t.pid,uid:t.uid};showPage("cr");};cl.appendChild(d);
      })(th[i]);}
    }
  }
  
  function renderCR(){
    if(!chatT)return;var o=getUser(chatT.uid);
    var prod=null;for(var i=0;i<products.length;i++)if(products[i].id===chatT.pid){prod=products[i];break;}
    document.getElementById("crHeader").innerHTML='<button style="font-size:18px;color:var(--mut);cursor:pointer;border:none;background:none" onclick="showPage(\'chat\')">←</button><span style="font-size:28px">'+o.avatar+'</span><div style="flex:1"><div style="font-weight:600;font-size:15px">'+esc(o.name)+'</div><div style="font-size:12px;color:var(--mut)">✓ Verified · ⭐ '+o.rating+'</div></div>';
    var crp=document.getElementById("crProduct");
    if(prod){crp.innerHTML='<span style="font-size:24px">'+prod.img+'</span><div><div style="font-size:13px;font-weight:600">'+esc(prod.title)+'</div><div style="font-size:13px;color:var(--pri);font-weight:700">$'+prod.price+'</div></div>';crp.style.display="flex";}
    else crp.style.display="none";
    renderMsgs(msgs[chatT.pid]||[]);
  }
  
  function renderMsgs(ms){
    var c=document.getElementById("crMessages");c.innerHTML="";
    for(var i=0;i<ms.length;i++){var m=ms[i],mine=m.f===me.id;
      c.innerHTML+='<div class="mr '+(mine?"mine":"theirs")+'"><div class="mb2">'+esc(m.tx)+'</div><div class="mt3">'+m.tm.slice(11)+'</div></div>';}
    c.scrollTop=c.scrollHeight;
  }
  
  async function sendMessage(){
    var inp=document.getElementById("crInput"),tx=inp.value.trim();if(!tx||!chatT)return;
    inp.value="";
    try{
      var data=await api("/api/messages",{method:"POST",body:JSON.stringify({pid:chatT.pid,from:me.id,to:chatT.uid,text:tx})});
      msgs[chatT.pid]=data.messages;
    }catch(e){
      if(!msgs[chatT.pid])msgs[chatT.pid]=[];
      msgs[chatT.pid].push({f:me.id,t:chatT.uid,tx:tx,tm:new Date().toISOString().replace("T"," ").slice(0,16)});
    }
    renderMsgs(msgs[chatT.pid]);
  }
  
  function renderProfile(){
    var u=me,mp=[];for(var i=0;i<products.length;i++)if(products[i].sid===u.id)mp.push(products[i]);
    var myRes=0;for(var r=0;r<bookings.length;r++)if(bookings[r].uid===u.id)myRes++;
    document.getElementById("profileHeader").innerHTML='<div class="pra">'+u.avatar+'</div><div style="flex:1"><div style="font-family:var(--fd);font-size:24px;font-weight:700;margin-bottom:4px">'+esc(u.name)+'</div><div style="font-size:14px;color:var(--mut);margin-bottom:8px">'+esc(u.email)+'</div><div style="display:flex;gap:16px;flex-wrap:wrap"><span style="background:var(--pril);color:var(--pri);padding:4px 12px;border-radius:8px;font-size:13px;font-weight:600">✓ Verified</span><span style="font-size:13px;color:var(--mut)">⭐ '+u.rating+'</span><span style="font-size:13px;color:var(--mut)">📅 Joined '+u.joined+'</span><span style="font-size:13px;color:var(--mut)">📌 Reservations '+myRes+'</span></div></div>';
    document.getElementById("myListTitle").textContent="My Listings ("+mp.length+")";
    var ml=document.getElementById("myListings"),pe=document.getElementById("profileEmpty");
    if(!mp.length){ml.innerHTML="";pe.style.display="block";}
    else{pe.style.display="none";ml.innerHTML="";
      for(var i=0;i<mp.length;i++){(function(p){
        var d=document.createElement("div");d.className="mli";
        d.innerHTML='<div class="mlic">'+thumb(p.img,"")+'</div><div style="flex:1;min-width:0"><div style="font-size:14px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+esc(p.title)+'</div><div style="font-size:16px;font-weight:700;color:var(--pri)">$'+p.price+'</div></div><span style="font-size:12px;color:var(--mut)">👁 '+p.views+'</span>';
        d.onclick=function(){selP=p;showPage("detail");};ml.appendChild(d);
      })(mp[i]);}
    }
  }
